﻿
var tempoRefresh = setInterval(mainLoop, 200);

var fadeTime = 1000;

var fileLoaded = 'test2.mp4';

//******************************************************************************
// Imposto nessuna chache per velocizzare lettura JSON
//******************************************************************************
$(document).ready(function() {
  $.ajaxSetup({ cache: false });
});

//******************************************************************************
function mainLoop() {
	
	$.getJSON('command.json')
	.done(function(data) {
		gestioneTempo(data);
		testo(data);
		video(data);
		audio(data);
	});
}

//******************************************************************************
// Tempo trascorso
//******************************************************************************
function gestioneTempo(data) {
	if (data.timer.visible == 1)
		$('#timer').show(fadeTime);
	else
		$('#timer').hide(fadeTime);
	
	// Timer
	if (data.timer.start == 1) {
		
		var distance = (data.timer.startSecond * 1000) - new Date().getTime();
		var str = "";

		if (data.timer.custom == 0) {
			// Time calculations for days, hours, minutes and seconds
			var days = Math.floor(distance / (1000 * 60 * 60 * 24));
			var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
			var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
			var seconds = Math.floor((distance % (1000 * 60)) / 1000);

			//If the count down is finished, write some text
			if (distance < 0) {
				document.getElementById("timer").innerHTML = "Tempo finito!";
			}
			else {
			
				if (minutes < 10) str = "0" + minutes; else str = minutes;
				if (seconds < 10) str = str + ":0" + seconds; else str = str + ":" + seconds;
			
				// Display the result in the element with id="demo"
				document.getElementById("timer").innerHTML = str;
			}
		}
		else {
		
		}
	}
	else {
		if (data.timer.custom == 0)
			document.getElementById("timer").innerHTML = "60:00";
		else
			document.getElementById("timer").innerHTML = "40 settimane";
	}

	
	/*if (data.timer.custom == 1) {
		// Tempo totale in settimane (40 settimane)
		diff = 40 - (diff / 90);
		// Filtro nel caso in cui si aggiunga più tempo del previsto
		if (diff > 40)
			diff = 40;
		if (data.config.language == 0)
			str = diff + " settimane";
		else
			str = diff + " week";
	}
	else {
        diff = 3600 - diff;
        minuti = diff / 60;
        secondi = diff - (minuti * 60);
        if (minuti < 10)
			str = "0" + minuti;
		else
			str = minuti;
        if (secondi < 10) 
			str = str + ":0" + secondi;
		else
			str = str + ":" + secondi;
    }
	
	document.getElementById('timer').innerHTML = str;
	*/
}

//******************************************************************************
// Testo
//******************************************************************************
function testo(data) {
	if (data.testo.visible == 1)
		$('#testo').show(fadeTime);
	else
		$('#testo').hide(fadeTime);
	
	// Testo
	document.getElementById("testo").innerHTML = data.testo.clueText;
}

//******************************************************************************
// Video
//******************************************************************************
function video(data) {
	// Show
	if (data.video.visible == 1)
		$('#video').show(fadeTime);
	else
		$('#video').hide(fadeTime);
	
	// File
	var video = document.getElementById('video_1');
	var fileUrl = data.video.fileUrl;
	if (fileLoaded != fileUrl)
	{
		fileLoaded = fileUrl;
		video.src = fileUrl;
	}
	
	// Play
	if (data.video.play == 1) {
		video.play();
	} else
		video.pause();
	
}

//******************************************************************************
// Audio
//******************************************************************************
function audio(data) {

	if (data.audio.visible == 1)
		$('#audio').show(fadeTime);
	else
		$('#audio').hide(fadeTime);
}



//******************************************************************************
//******************************************************************************
/*
function playPause()
{
	var myVideo = document.getElementById('#video_1');
	
	if (myVideo.paused) {
		myVideo.play();
	} else {
		myVideo.pause();
	}
}

function makeBig() {
	var myVideo = document.getElementById('myvideo');
    myVideo.width = 560;
	myVideo.show = false;
}
 
function makeSmall() {
	var myVideo = document.getElementById('myvideo');
    myVideo.width = 320;
}
 
function makeNormal() {
	var myVideo = document.getElementById('myvideo');
    myVideo.width = 420;
}

function dowload() {
	$.getJSON('http://10.10.2.3/command.json', function(data){
		var items = [];
		$.each( data, function( key, val ) {
			items.push( "<li id='" + key + "'>" + val + "</li>" );
		});
		$( "<ul/>", {"class": "my-new-list", html: items.join( "" )}).appendTo( "body" );
	});
}
*/